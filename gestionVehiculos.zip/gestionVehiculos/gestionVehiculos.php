<?php

/**
Autor= hlozsando
Fecha= 21/02/2019
Licencia= gpl30
Version= 1.0
*/

/*
  ~ Copyright (C) hlozsando 2018
  ~
  ~
  ~ This program is free software: you can redistribute it and/or modify
  ~
  ~ it under the terms of the GNU General Public License as published by
  ~
  ~ the Free Software Foundation, either version 3 of the License, or
  ~
  ~ (at your option) any later version.
  ~
  ~
  ~
  ~ This program is distributed in the hope that it will be useful,
  ~
  ~ but WITHOUT ANY WARRANTY; without even the implied warranty of
  ~
  ~ MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
  ~
  ~ GNU General Public License for more details.
  ~
  ~
  ~
  ~ You should have received a copy of the GNU General Public License
  ~
  ~ along with this program.  If not, see <http://www.gnu.org/licenses/>
 */

// Constantes para la creacion y acceso a la base de datos
define('USUARIO', 'root');
define('PASSWORD', '');
define('SERVER', 'localhost');
define('DATABASE', 'mispruebas');

// Funcion que hace una consulta SQL para saber el promedio de vehiculos de cada color de la base de datos
function consulta($color)
{

// Creacion de la conexion a la base de datos. Recibe el servidor, usuario y contraseña
    $conexion = mysqli_connect(SERVER, USUARIO, PASSWORD) or die ('No se ha podido conectar con la base de datos');

// Conexion a la base de datos. Recibe la conexion previamente creada y el nombre de la base de datos
    $db = mysqli_select_db($conexion, DATABASE) or die('Ha ocurrido un error al conectar con la base de datos');

// Creacion de la consulta
    // Se realiza el tanto % de los colores y devuelve el promedio de vehiculos segun el color
    $sql = "select round(count(color)/(select count(id) from vehiculos)*100) as Promedio from vehiculos where color = " . "'" . $color . "'";

// Ejecucion de la consulta. Recibe la conexion y la propia consulta
    $resultado = mysqli_query($conexion, $sql) or die ('Error en la consulta');

// Se almacena el array asociativo devuelto
    $datos = mysqli_fetch_assoc($resultado);

// Cierre de la conexion
    mysqli_close($conexion);

// Retorno de la conulta
    return "El porcentaje de coches de color $color es " . $datos['Promedio'] . "%";
}

// Funcion que vuelca los datos de la consulta sql sobre un fichero.txt
function editarRegistro($datos)
{
    // Fichero sobre el que volcar los datos
    $nombre_archivo = "registro.txt";

    // Se almacena la orden de apertura del fichero. El primer parametro es el archivo a brir, el segundo el modo de apertura
    // En este caso se abre en modo lectura y se posiciona el puntero al final
    $archivo = fopen($nombre_archivo, "a");
    if (fwrite($archivo, $datos . "\n")) {
        echo "El registro se ha modificado<br>";
    } else {
        echo "Ha habido un problema al modificar el archivo";
    }
    // Se cierra el archivo
    fclose($archivo);
}

// Se almacenan los datos de la consulta y se le pasan a editarRegistro()
$consulta = consulta('rojo');
editarRegistro($consulta);
$consulta = consulta('azul');
editarRegistro($consulta);
$consulta = consulta('naranja');
editarRegistro($consulta);
$consulta = consulta('gris');
editarRegistro($consulta);